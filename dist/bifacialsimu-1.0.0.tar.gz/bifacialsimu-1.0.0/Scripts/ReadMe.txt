The following skripts need to be copied into the local installation folders of bifacial_radiance and pvfactors

bifacial_radiance:
- load
- main


pvfactors:
- pvarray
- pvground


example installation path:
- bifacial_radiance: C:\Users\sarah\anaconda3\Lib\site-packages\bifacial_radiance
- pvfactors: C:\Users\sarah\anaconda3\Lib\site-packages\pvfactors\geometry